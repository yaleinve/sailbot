^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Change log for nmea_msgs package
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.1 (2015-02-15)
------------------
* Cleanup CMakeLists.txt and package.xml

0.1.0 (2013-07-21)
------------------
* Initial version (released into Hydro)
* Supports NMEA0183 sentences
